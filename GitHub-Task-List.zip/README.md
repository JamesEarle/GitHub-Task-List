# GitHub-Task-List

This small chrome extension creates richer issue links in GitHub, providing you with more information about any given issue from a high level perspective.

You can download it [here, on the Chrome Web Store](https://chrome.google.com/webstore/detail/github-task-list/bhajciggpdkcmcimnjbaafgmdppmagnb)

**Before**
![Image before extension installation](http://i.imgur.com/SX0rLge.jpg)

**After**
![Image after extension installation](http://i.imgur.com/hsMTcyG.jpg)
